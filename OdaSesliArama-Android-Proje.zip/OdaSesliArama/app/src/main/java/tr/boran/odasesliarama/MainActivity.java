package tr.boran.odasesliarama;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONObject;
import org.webrtc.*;
import java.net.URI;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

public class MainActivity extends Activity {
    // Replace with your deployed WSS signaling server URL. Example: wss://your-domain.example
    private static final String SIGNALING_URL = "wss://CHANGE-ME.example";
    private EditText roomInput;
    private TextView status;
    private Button joinButton, callButton, acceptButton, hangupButton;
    private WebSocketClient socket;
    private PeerConnectionFactory factory;
    private PeerConnection peer;
    private AudioSource audioSource;
    private AudioTrack audioTrack;
    private String room = "";
    private JSONObject pendingOffer;
    private boolean joined = false;
    private final Queue<IceCandidate> queuedCandidates = new ConcurrentLinkedQueue<>();
    private boolean remoteDescriptionSet = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 42);
        } else initWebRtc();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 28);
        root.setBackgroundColor(Color.rgb(247, 249, 252));
        TextView title = new TextView(this);
        title.setText("Oda Sesli Arama");
        title.setTextSize(26); title.setTextColor(Color.rgb(22, 50, 79));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView info = new TextView(this);
        info.setText("Arkadaşınla aynı oda kodunu girin. İkiniz de uygulamayı açık tutun.");
        info.setTextSize(15); info.setPadding(0, 14, 0, 14);
        root.addView(info);
        roomInput = new EditText(this);
        roomInput.setSingleLine(true); roomInput.setHint("Oda kodu (örn. BORAN26)");
        root.addView(roomInput);
        joinButton = button("Odaya bağlan");
        callButton = button("Sesli arama başlat");
        acceptButton = button("Gelen aramayı kabul et");
        hangupButton = button("Aramayı bitir");
        root.addView(joinButton); root.addView(callButton); root.addView(acceptButton); root.addView(hangupButton);
        status = new TextView(this); status.setText("Sunucu adresi yapılandırılmalı.");
        status.setTextSize(14); status.setPadding(0, 20, 0, 0);
        root.addView(status);
        setContentView(root);
        callButton.setEnabled(false); acceptButton.setEnabled(false); hangupButton.setEnabled(false);
        joinButton.setOnClickListener(v -> joinRoom());
        callButton.setOnClickListener(v -> startCall());
        acceptButton.setOnClickListener(v -> acceptCall());
        hangupButton.setOnClickListener(v -> hangup());
    }

    private Button button(String text) {
        Button b = new Button(this); b.setText(text);
        return b;
    }

    @Override public void onRequestPermissionsResult(int req, String[] p, int[] g) {
        super.onRequestPermissionsResult(req, p, g);
        if (req == 42 && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) initWebRtc();
        else status.setText("Sesli görüşme için mikrofon izni gereklidir.");
    }

    private void initWebRtc() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions());
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory();
        status.setText("Hazır. Önce sunucu adresini yapılandır.");
    }

    private void joinRoom() {
        if (factory == null) { status.setText("Mikrofon iznini verip uygulamayı yeniden aç."); return; }
        room = roomInput.getText().toString().trim().toUpperCase(Locale.ROOT);
        if (!room.matches("[A-Z0-9_-]{4,32}")) {
            status.setText("Oda kodu 4-32 karakter olmalı; harf, sayı, _ veya - kullan.");
            return;
        }
        if (SIGNALING_URL.contains("CHANGE-ME")) {
            status.setText("Önce MainActivity.java içindeki SIGNALING_URL değerini kendi WSS sunucu adresinle değiştir.");
            return;
        }
        try {
            socket = new WebSocketClient(new URI(SIGNALING_URL)) {
                @Override public void onOpen(ServerHandshake h) {
                    sendJson(new JSONObject().put("type", "join").put("room", room));
                    runOnUiThread(() -> status.setText("Sunucuya bağlandı; odaya katılınıyor..."));
                }
                @Override public void onMessage(String raw) {
                    try { handleSignal(new JSONObject(raw)); }
                    catch (Exception e) { runOnUiThread(() -> status.setText("Sinyal mesajı okunamadı.")); }
                }
                @Override public void onClose(int code, String reason, boolean remote) {
                    runOnUiThread(() -> { joined = false; callButton.setEnabled(false); status.setText("Sunucu bağlantısı kapandı: " + reason); });
                }
                @Override public void onError(Exception e) {
                    runOnUiThread(() -> status.setText("Sunucu bağlantı hatası: " + e.getMessage()));
                }
            };
            socket.connect();
        } catch (Exception e) { status.setText("Sunucu adresi geçersiz: " + e.getMessage()); }
    }

    private void handleSignal(JSONObject m) throws Exception {
        String type = m.optString("type");
        if ("joined".equals(type)) {
            joined = true;
            runOnUiThread(() -> { status.setText("Odaya bağlandın: " + room); callButton.setEnabled(true); });
        } else if ("peer-joined".equals(type)) {
            runOnUiThread(() -> status.setText("Arkadaşın odaya katıldı."));
        } else if ("offer".equals(type)) {
            pendingOffer = m;
            runOnUiThread(() -> { status.setText("Gelen arama var. Kabul etmek için düğmeye bas."); acceptButton.setEnabled(true); });
        } else if ("answer".equals(type)) {
            if (peer != null) {
                SessionDescription s = new SessionDescription(SessionDescription.Type.ANSWER, m.getString("sdp"));
                peer.setRemoteDescription(new SdpObserverAdapter(), s);
                remoteDescriptionSet = true; flushCandidates();
            }
        } else if ("candidate".equals(type)) {
            IceCandidate c = new IceCandidate(m.getString("sdpMid"), m.optInt("sdpMLineIndex"), m.getString("candidate"));
            if (peer != null && remoteDescriptionSet) peer.addIceCandidate(c); else queuedCandidates.add(c);
        } else if ("hangup".equals(type)) {
            runOnUiThread(() -> { closePeer(); status.setText("Arkadaşın aramayı bitirdi."); });
        } else if ("error".equals(type)) {
            runOnUiThread(() -> status.setText("Sunucu: " + m.optString("message")));
        }
    }

    private void startCall() {
        if (!joined) return;
        createPeer();
        peer.createOffer(new SdpObserverAdapter() {
            @Override public void onCreateSuccess(SessionDescription s) {
                peer.setLocalDescription(new SdpObserverAdapter() {
                    @Override public void onSetSuccess() {
                        sendJsonSafe(new JSONObject().put("type","offer").put("sdp",s.description));
                        runOnUiThread(() -> { status.setText("Arama isteği gönderildi; arkadaşının kabul etmesini bekle."); hangupButton.setEnabled(true); });
                    }
                }, s);
            }
            @Override public void onCreateFailure(String e) { showStatus("Arama oluşturulamadı: " + e); }
        }, new MediaConstraints());
    }

    private void acceptCall() {
        if (pendingOffer == null) return;
        try {
            createPeer();
            SessionDescription offer = new SessionDescription(SessionDescription.Type.OFFER, pendingOffer.getString("sdp"));
            peer.setRemoteDescription(new SdpObserverAdapter() {
                @Override public void onSetSuccess() {
                    remoteDescriptionSet = true; flushCandidates();
                    peer.createAnswer(new SdpObserverAdapter() {
                        @Override public void onCreateSuccess(SessionDescription answer) {
                            peer.setLocalDescription(new SdpObserverAdapter() {
                                @Override public void onSetSuccess() {
                                    sendJsonSafe(new JSONObject().put("type","answer").put("sdp",answer.description));
                                    runOnUiThread(() -> { status.setText("Arama bağlanıyor..."); acceptButton.setEnabled(false); hangupButton.setEnabled(true); });
                                }
                            }, answer);
                        }
                        @Override public void onCreateFailure(String e) { showStatus("Yanıt oluşturulamadı: " + e); }
                    }, new MediaConstraints());
                }
                @Override public void onSetFailure(String e) { showStatus("Gelen arama açılamadı: " + e); }
            }, offer);
            pendingOffer = null;
        } catch (Exception e) { showStatus("Arama kabul edilemedi: " + e.getMessage()); }
    }

    private void createPeer() {
        closePeer();
        PeerConnection.RTCConfiguration cfg = new PeerConnection.RTCConfiguration(Arrays.asList(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        ));
        peer = factory.createPeerConnection(cfg, new PeerConnection.Observer() {
            @Override public void onSignalingChange(PeerConnection.SignalingState s) {}
            @Override public void onIceConnectionChange(PeerConnection.IceConnectionState s) {
                showStatus("Bağlantı durumu: " + s.toString());
            }
            @Override public void onStandardizedIceConnectionChange(PeerConnection.IceConnectionState s) {}
            @Override public void onConnectionChange(PeerConnection.PeerConnectionState s) { showStatus("Arama durumu: " + s); }
            @Override public void onIceConnectionReceivingChange(boolean b) {}
            @Override public void onIceGatheringChange(PeerConnection.IceGatheringState s) {}
            @Override public void onIceCandidate(IceCandidate c) {
                try { sendJsonSafe(new JSONObject().put("type","candidate").put("sdpMid",c.sdpMid)
                    .put("sdpMLineIndex",c.sdpMLineIndex).put("candidate",c.sdp)); } catch (Exception ignored) {}
            }
            @Override public void onIceCandidatesRemoved(IceCandidate[] c) {}
            @Override public void onAddStream(MediaStream s) {}
            @Override public void onRemoveStream(MediaStream s) {}
            @Override public void onDataChannel(DataChannel d) {}
            @Override public void onRenegotiationNeeded() {}
            @Override public void onAddTrack(RtpReceiver r, MediaStream[] s) {}
        });
        audioSource = factory.createAudioSource(new MediaConstraints());
        audioTrack = factory.createAudioTrack("local-audio", audioSource);
        peer.addTrack(audioTrack);
        remoteDescriptionSet = false;
    }

    private void flushCandidates() {
        IceCandidate c;
        while ((c = queuedCandidates.poll()) != null) if (peer != null) peer.addIceCandidate(c);
    }

    private void hangup() {
        sendJsonSafe(new JSONObject().put("type","hangup"));
        closePeer();
        runOnUiThread(() -> { status.setText("Arama bitti."); hangupButton.setEnabled(false); acceptButton.setEnabled(false); });
    }

    private void closePeer() {
        if (peer != null) { peer.close(); peer.dispose(); peer = null; }
        if (audioTrack != null) { audioTrack.dispose(); audioTrack = null; }
        if (audioSource != null) { audioSource.dispose(); audioSource = null; }
        remoteDescriptionSet = false;
        queuedCandidates.clear();
        runOnUiThread(() -> hangupButton.setEnabled(false));
    }

    private void sendJson(JSONObject o) { if (socket != null && socket.isOpen()) socket.send(o.toString()); }
    private void sendJsonSafe(JSONObject o) { sendJson(o); }
    private void showStatus(String s) { runOnUiThread(() -> status.setText(s)); }

    @Override protected void onDestroy() {
        closePeer();
        if (socket != null) socket.close();
        if (factory != null) factory.dispose();
        super.onDestroy();
    }

    private static class SdpObserverAdapter implements SdpObserver {
        @Override public void onCreateSuccess(SessionDescription s) {}
        @Override public void onSetSuccess() {}
        @Override public void onCreateFailure(String s) {}
        @Override public void onSetFailure(String s) {}
    }
}
