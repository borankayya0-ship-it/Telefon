'use strict';
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: process.env.PORT || 8080 });
const rooms = new Map();

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function validRoom(s) {
  return typeof s === 'string' && /^[A-Z0-9_-]{4,32}$/.test(s);
}
wss.on('connection', (ws) => {
  ws.room = null;
  ws.on('message', (raw) => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return send(ws, {type:'error', message:'Geçersiz mesaj'}); }
    if (m.type === 'join') {
      const room = String(m.room || '').toUpperCase();
      if (!validRoom(room)) return send(ws, {type:'error', message:'Oda kodu geçersiz'});
      if (ws.room) return send(ws, {type:'error', message:'Zaten bir odadasın'});
      const peers = rooms.get(room) || new Set();
      if (peers.size >= 2) return send(ws, {type:'error', message:'Oda dolu; en fazla iki kişi katılabilir'});
      ws.room = room;
      peers.add(ws);
      rooms.set(room, peers);
      send(ws, {type:'joined', room});
      for (const p of peers) if (p !== ws) send(p, {type:'peer-joined'});
      return;
    }
    if (!ws.room) return send(ws, {type:'error', message:'Önce odaya katıl'});
    const allowed = new Set(['offer','answer','candidate','hangup']);
    if (!allowed.has(m.type)) return;
    const peers = rooms.get(ws.room) || new Set();
    for (const p of peers) if (p !== ws) send(p, m);
  });
  ws.on('close', () => {
    if (!ws.room) return;
    const peers = rooms.get(ws.room);
    if (!peers) return;
    peers.delete(ws);
    for (const p of peers) send(p, {type:'hangup'});
    if (!peers.size) rooms.delete(ws.room);
  });
});
console.log(`Signaling server listening on port ${process.env.PORT || 8080}`);
