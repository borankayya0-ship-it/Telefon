# Sinyal sunucusu

Bu sunucu sadece WebRTC bağlantı kurulum mesajlarını (offer/answer/ICE) aktarır; ses sunucudan geçmez.

## Yerel test
1. Node.js 20+ kur.
2. `cd server`
3. `npm install`
4. `npm start`

Bu yerel adres internetteki telefonlardan erişilemez. Üretimde HTTPS/WSS destekleyen bir platforma dağıt ve `PORT` ortam değişkenini kullan. Uygulamada `ws://` yerine `wss://` adresi yaz.

## Güvenlik ve sınırlar
- Bu örnek demo amaçlıdır; oda kodu tek başına kimlik doğrulama değildir.
- Üretimde oda başına kısa ömürlü erişim anahtarı, hız sınırı, TLS, log politikası ve kötüye kullanım önlemleri ekle.
- STUN tek başına her ağda bağlantıyı garanti etmez. Güvenilir erişim için TURN servisi kurup `MainActivity.java` içindeki `RTCConfiguration` listesine TURN kullanıcı adı/parolası ekle.
