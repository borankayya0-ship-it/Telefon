# Oda Sesli Arama (Android)

Türkçe demo uygulama: ortak oda kodu, uygulama açıkken gelen aramayı kabul etme ve WebRTC ses bağlantısı.

## APK derlemesi
1. Bu projeyi GitHub deposuna yükle.
2. `.github/workflows/build-apk.yml` dosyası aynen bu yolda bulunmalı.
3. GitHub > Actions > **Android APK oluştur** > **Run workflow**.
4. Başarılı çalışmada `OdaSesliArama-debug-apk` adlı artifact'i açıp APK'yı indir.

## Sunucu ayarı gerekli
1. `server/` içindeki Node.js sinyal sunucusunu WSS destekleyen bir hizmete dağıt.
2. `app/src/main/java/tr/boran/odasesliarama/MainActivity.java` dosyasındaki `SIGNALING_URL` sabitini sunucunun gerçek `wss://...` adresiyle değiştir.
3. Yeniden derle.

## Bilinen sınırlamalar
- Kaynak kodu bu ortamda Android SDK/Gradle ile derlenip gerçek iki telefonda test edilmedi; bu nedenle hatasız/üretime hazır olduğu garanti edilmez.
- STUN adresi temel bağlantı denemesi içindir; bazı ağlarda TURN sunucusu gerekir. TURN ayarı olmadan her ağda bağlantı garantisi yoktur.
- Sunucu demo amaçlıdır; oda kodu doğrulama/kimlik doğrulama yerine geçmez.
- İlk sürümde uygulama açıkken kullanım hedeflenmiştir; arka plan bildirimi yoktur.
